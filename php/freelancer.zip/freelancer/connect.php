<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 2:51 PM
 */

$link = mysqli_connect('localhost','root','','db1312102');

?>