<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 3:13 PM
 */
session_start();
include('connect.php');
require('./smartyHeader.php');

if($_POST['deletename'] == "" || $_POST['deletenumber'] == ""){
    $smarty->clearCache("test.tpl");

    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";

    $title ="Alert";

    $msg .= "Enter all the information";

}else{
    $queryfind = "SELECT * FROM Members WHERE Player_name = '".$_POST['deletename']."' AND Player_number= '".$_POST['deletenumber']."'";

    $resultfind = mysqli_query($link,$queryfind);

    $rowfind = mysqli_fetch_array($resultfind);

    if($rowfind){
        $querydelete = "DELETE FROM Members WHERE Player_name = '".$_POST['deletename']."' AND Player_number= '".$_POST['deletenumber']."'";

        if(!$resultdelete = mysqli_query($link,$querydelete)){
            printf("Error: %s\n", mysqli_error($link));
        }
    }

    $smarty->clearCache("test.tpl");

    $title ="Success";

    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";


    $msg .= "Deleted";
}

$smarty->assign('title',$title);
$smarty->assign('message',$msg);

$smarty->display('test.tpl');







?>