<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 2:27 PM
 */

//set up smarty template

require_once("./Smarty/libs/Smarty.class.php");

$smarty = new Smarty;

$smarty->caching = true;
$smarty->cache_lifetime = 120;
$smarty->template_dir = './templates';
$smarty->compile_dir = './templates_c';


?>