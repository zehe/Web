<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 3:13 PM
 */
session_start();
include('connect.php');
require('./smartyHeader.php');

if($_POST['submit']=="Display all Members"){

    $smarty->clearCache('test.tpl');
    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";
    $query1 = "SELECT * FROM Members";

    $result = mysqli_query($link,$query1);



    $msg .= "<table style='border: 1px solid grey;'>
  <tr>
    <th>Player_name</th>
    <th>Player_number</th>
    <th>Player_role</th>
    <th>DOB</th>
    <th>Country</th>
  </tr>";

    while($rows = mysqli_fetch_array($result)){
        $msg .= "<tr><td>".$rows['Player_name']."</td><td>".$rows['Player_number']."</td><td>".$rows['Player_role']."</td><td>".$rows['DOB']."</td><td>".$rows['Country']."</td></tr>";
    }

    $msg .= "</table>";

    $title = 'result1';

}elseif($_POST['submit']=="Display all Fixtures"){
    $smarty->clearCache('test.tpl'); //clear the cache of smarty

    $msg = "User:".$_SESSION['team']."<br>"; //get the value of session
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>"; //get the value of cookie
    $query2 = "SELECT * FROM Fixtures";

    $result2 = mysqli_query($link,$query2);



    $msg .= "<table style='border: 1px solid grey;'>
  <tr>
    <th>Team</th>
    <th>Stadium</th>
    <th>Date</th>
  </tr>";

    while($rows2 = mysqli_fetch_array($result2)){
        $msg .= "<tr><td>".$rows2['Team']."</td><td>".$rows2['Stadium']."</td><td>".$rows2['Date']."</td></tr>";
    }

    $msg .= "</table>";

    $title = 'result2';

}


$smarty->assign('title',$title);
$smarty->assign('message',$msg);

$smarty->display('test.tpl');






?>