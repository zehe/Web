<?php /* Smarty version 3.1.27, created on 2015-11-25 23:00:59
         compiled from "/Users/hze/Desktop/My Websites/php/freelancer/test.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:86650995356562f9ba471a1_08822477%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1785834441b5579ca6d04cb1dc3f44887d88ef32' => 
    array (
      0 => '/Users/hze/Desktop/My Websites/php/freelancer/test.tpl',
      1 => 1448483386,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '86650995356562f9ba471a1_08822477',
  'variables' => 
  array (
    'title' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56562f9ba89a75_89526706',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56562f9ba89a75_89526706')) {
function content_56562f9ba89a75_89526706 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '86650995356562f9ba471a1_08822477';
?>
<html>
    <head>
        <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
    </head>

    <body>
        <?php echo $_smarty_tpl->tpl_vars['message']->value;?>


    </body>
</html><?php }
}
?>