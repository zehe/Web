<?php /* Smarty version 3.1.27, created on 2015-11-25 21:29:49
         compiled from "/Users/hze/Desktop/My Websites/php/freelancer/test.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:134798075256561a3d4abc32_72554446%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1785834441b5579ca6d04cb1dc3f44887d88ef32' => 
    array (
      0 => '/Users/hze/Desktop/My Websites/php/freelancer/test.tpl',
      1 => 1448483386,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134798075256561a3d4abc32_72554446',
  'variables' => 
  array (
    'title' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56561a3d4c7a91_67089053',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56561a3d4c7a91_67089053')) {
function content_56561a3d4c7a91_67089053 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '134798075256561a3d4abc32_72554446';
?>
<html>
    <head>
        <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
    </head>

    <body>
        <?php echo $_smarty_tpl->tpl_vars['message']->value;?>


    </body>
</html><?php }
}
?>