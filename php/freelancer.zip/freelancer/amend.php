<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 3:13 PM
 */
session_start();
include('connect.php');
require('./smartyHeader.php');

if($_POST['amendname'] == "" || $_POST['amendnumber'] == "" || $_POST['amendrole'] == "" || $_POST['amenddob'] == "" || $_POST['amendcountry'] == ""){
    $smarty->clearCache("test.tpl");
    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";

    $title ="Alert";

    $msg .= "Enter all the information";

}else{
    $queryfind = "SELECT * FROM Members WHERE Player_name = '".$_POST['amendname']."' AND Player_number= '".$_POST['amendnumber']."'";

    $resultfind = mysqli_query($link,$queryfind);

    $rowfind = mysqli_fetch_array($resultfind);

    if($rowfind){
        $queryupdate = "UPDATE Members SET Player_role='".$_POST['amendrole']."', DOB='".$_POST['amenddob']."', Country ='".$_POST['amendcountry']."'
        WHERE Player_name = '".$_POST['amendname']."' AND Player_number= '".$_POST['amendnumber']."'";

        if(!$resultupdate = mysqli_query($link,$queryupdate)){
            printf("Error: %s\n", mysqli_error($link));
        }
    }

    $smarty->clearCache("test.tpl");

    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";

    $title ="Success";


    $msg .= "Updated";
}

$smarty->assign('title',$title);
$smarty->assign('message',$msg);

$smarty->display('test.tpl');







?>