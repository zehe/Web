<?php
/*%%SmartyHeaderCode:134798075256561a3d4abc32_72554446%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1785834441b5579ca6d04cb1dc3f44887d88ef32' => 
    array (
      0 => '/Users/hze/Desktop/My Websites/php/freelancer/test.tpl',
      1 => 1448483386,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134798075256561a3d4abc32_72554446',
  'tpl_function' => 
  array (
  ),
  'version' => '3.1.27',
  'unifunc' => 'content_565643685a6578_42608536',
  'has_nocache_code' => false,
  'cache_lifetime' => 120,
),true);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_565643685a6578_42608536')) {
function content_565643685a6578_42608536 ($_smarty_tpl) {
?>
<html>
    <head>
        <title>result1</title>
    </head>

    <body>
        User:Aston Villa<br>Log in time:2015-Nov-26<br><table style='border: 1px solid grey;'>
  <tr>
    <th>Player_name</th>
    <th>Player_number</th>
    <th>Player_role</th>
    <th>DOB</th>
    <th>Country</th>
  </tr><tr><td>Alexis Sanchez</td><td>17</td><td>Striker</td><td>1988-12-19</td><td>Chile </td></tr><tr><td>Danny Welbeck</td><td>23</td><td>Striker</td><td>1990-11-26</td><td>England</td></tr><tr><td>Joel Campbell</td><td>28</td><td>Striker</td><td>1992-06-26</td><td>Costa Rica</td></tr><tr><td>Olivier Giroud</td><td>12</td><td>Striker</td><td>1986-09-30</td><td>France</td></tr><tr><td>Theo Walcott</td><td>14</td><td>Striker</td><td>1989-03-16</td><td>England</td></tr></table>

    </body>
</html><?php }
}
?>