<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 5:59 PM
 */
$cookiename = "logintime";
$cookievalue = date("Y-M-d");
?>