<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 2:34 PM
 */
require('./smartyHeader.php');

$msg = 'Hello World';
$title = 'Hello Smarty World';

$smarty->assign('title',$title);
$smarty->assign('message',$msg);

$smarty->display('test.tpl');
?>