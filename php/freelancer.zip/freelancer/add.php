<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 3:13 PM
 */

//add member to the databse

session_start(); //start session

include('connect.php');
require('./smartyHeader.php');

if($_POST['addname'] == "" || $_POST['addnumber'] == "" || $_POST['addrole'] == "" || $_POST['adddob'] == "" || $_POST['addcountry'] == ""){
    $smarty->clearCache("test.tpl");
    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";

    $title ="Alert";

    $msg .= "Enter all the information";

}else{
    $smarty->clearCache("test.tpl");

    $query = "INSERT INTO `Members`(`Player_name`, `Player_number`, `Player_role`, `DOB`, `Country`)
VALUES ('".$_POST['addname']."','".$_POST['addnumber']."','".$_POST['addrole']."','".$_POST['adddob']."','".$_POST['addcountry']."')";

    //mysqli_query($link,$query);

    if (!mysqli_query($link,$query)) {
        printf("Error: %s\n", mysqli_error($link));
    }

    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";

    $title ="Success";


    $msg .= "Added";
}

$smarty->assign('title',$title);
$smarty->assign('message',$msg);

$smarty->display('test.tpl');







?>

