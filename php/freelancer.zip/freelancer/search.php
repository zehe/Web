<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 3:13 PM
 */
session_start();
include('connect.php');
require('./smartyHeader.php');

if($_POST['searchname'] == "" || $_POST['searchnumber'] == "" || $_POST['searchrole'] == ""){
    $smarty->clearCache("test.tpl");
    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";
    $query1 = "SELECT * FROM Members";

    $result = mysqli_query($link,$query1);



    $msg .= "<table style='border: 1px solid grey;'>
  <tr>
    <th>Player_name</th>
    <th>Player_number</th>
    <th>Player_role</th>
    <th>DOB</th>
    <th>Country</th>
  </tr>";

    while($rows = mysqli_fetch_array($result)){
        $msg .= "<tr><td>".$rows['Player_name']."</td><td>".$rows['Player_number']."</td><td>".$rows['Player_role']."</td><td>".$rows['DOB']."</td><td>".$rows['Country']."</td></tr>";
    }

    $msg .= "</table>";

    $title = 'result1';

}else{
    $smarty->clearCache("test.tpl");
    $msg = "User:".$_SESSION['team']."<br>";
    $msg .= "Log in time:".$_COOKIE["logintime"]."<br>";


    $query2 = "SELECT * FROM Members WHERE Player_name = '".$_POST['searchname']."' OR Player_number= '".$_POST['searchnumber']."' OR Player_role = '".$_POST['searchrole']."'";

    //mysqli_query($link,$query);

    if (!mysqli_query($link,$query2)) {
        printf("Error: %s\n", mysqli_error($link));
    }

    $result2 = mysqli_query($link,$query2);

    $msg .= "<table style='border: 1px solid grey;'>
  <tr>
    <th>Player_name</th>
    <th>Player_number</th>
    <th>Player_role</th>
    <th>DOB</th>
    <th>Country</th>
  </tr>";

    while($rows2 = mysqli_fetch_array($result2)){
        $msg .= "<tr><td>".$rows2['Player_name']."</td><td>".$rows2['Player_number']."</td><td>".$rows2['Player_role']."</td><td>".$rows2['DOB']."</td><td>".$rows2['Country']."</td></tr>";
    }

    $msg .= "</table>";

    $title = 'result1';
}

$smarty->assign('title',$title);
$smarty->assign('message',$msg);

$smarty->display('test.tpl');







?>

