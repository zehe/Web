<?php
/**
 * Created by PhpStorm.
 * User: hze
 * Date: 11/25/15
 * Time: 3:23 PM
 */
session_start();

include("cookies.php");
require('./smartyHeader.php');

if(isset($_POST['submit'])){


    if($_POST['submit']=="Log in"){
        setcookie($cookiename,$cookievalue,time()+24*60*60); //set cookie

        $_SESSION['team'] = $_POST['teamname']; //set session

        header("Location:mainpage.html"); //change to mainpage.php
    }
    else{
        $msg = 'You have to enter your team name'; //use smarty template
        $title = 'Alert';

        $smarty->assign('title',$title);
        $smarty->assign('message',$msg);

        $smarty->display('test.tpl');
    }

}
?>